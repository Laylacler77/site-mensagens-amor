# Mensagens de Amor

Um site interativo com mensagens positivas e motivacionais.

## Características

- Mensagens de amor, conforto, motivação, amizade e gratidão
- Design responsivo
- Animações suaves
- Interface intuitiva
- Compartilhamento fácil

## Tecnologias Utilizadas

- HTML5
- CSS3
- JavaScript
- Fontes do Google Fonts

## Como Usar

1. Clique nos botões para receber mensagens especiais
2. Use o menu lateral para mudar entre diferentes tópicos
3. Compartilhe o site com amigos e familiares

## Criado por

Layla Cler
- Instagram: [@_layla_cler_](https://instagram.com/_layla_cler_) 